<template>
  <div id="app">
    <!-- <navbar v-if="$route.path !== '/register' && $route.path !== '/auth'"></navbar> -->
    <!-- <my-registration></my-registration> -->
    <!-- <my-authentication></my-authentication> -->
    <!-- <my-chat-page></my-chat-page> -->
    <!-- <my-chat></my-chat> -->
    <!-- <my-create-conference></my-create-conference> -->
    <!-- <my-waiting-hall></my-waiting-hall> -->
    <!-- <my-conference></my-conference> -->
    <!-- <my-team></my-team> -->
    <!-- <my-team-page></my-team-page> -->
    <router-view></router-view>
  </div>
</template>

<script>
// import MyChatPage from './components/MyChatPage.vue';
// import Navbar from './components/MyNavbar.vue';
// import MyChat from './components/MyChat.vue';
// import MyRegistration from './components/MyRegistration.vue';
// import MyAuthentication from './components/MyAuthentication.vue';
// import MyCreateConference from './components/MyCreateConference.vue';
// import MyWaitingHall from './components/MyWaitingHall.vue';
// import MyConference from './components/MyConference.vue';
// import MyTeam from './components/MyTeam.vue';
// import MyTeamPage from './components/MyTeamPage.vue';

export default {
  name: 'App',
  components: {
    // Navbar,
    // MyChatPage,
    // MyChat
    // MyRegistration,
    // MyAuthentication
    // MyCreateConference
    // MyWaitingHall
    // MyConference
    // MyTeam
    // MyTeamPage
}
}
</script>

<style>
#app {
  font-family: Arial, Helvetica, sans-serif;
}
</style>
