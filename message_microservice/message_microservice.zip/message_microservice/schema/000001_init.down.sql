drop table users_messages;
drop table messages;